import SessionDetails from '../../ui/dashboard/session-details';

export default function Page() {
  return <SessionDetails />;
}
